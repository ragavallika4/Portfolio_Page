const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json()); // For parsing application/json

// Create a connection to the MySQL database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Raga@123$',
    database: 'myUsersDB'
});

// Connect to MySQL
connection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL!');
});

// Serve static files (your HTML files)
app.use(express.static(path.join('F:', 'LRD')));

// Route to handle login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    // Query to check the credentials
    const query = 'SELECT * FROM tblUsers WHERE username = ? AND password = ?';
    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Database query error:', err);
            res.json({ success: false, message: 'An error occurred' });
            return;
        }

        if (results.length > 0) {
            res.json({ success: true, message: `Welcome ${username}!` });
        } else {
            res.json({ success: false, message: 'Invalid username or password' });
        }
    });
});

// Start the server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
